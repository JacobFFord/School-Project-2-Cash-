#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main(void)
{
    float change = 0.0;
    int coin_counter = 0;
    int cents;
   
    //check to make sure input is a positive demical number
    do
   {   
    change = get_float("Amount of change owed:");
        cents = round(change * 100);
   }
    while (change < 0);
    
    //subtract a quarter from amount of change owed as many times as possible 
    while (cents>=25)
   {
       cents = cents - 25;
        coin_counter = coin_counter + 1;     
   }
    //subtract a dime as many times as possible 
    while (cents>=10)
    {
        coin_counter = coin_counter  + 1;
            cents = cents - 10;
    }
    //subtract a nickel as many times as possible 
    while (cents>=5)
    {
        coin_counter = coin_counter + 1;
            cents = cents - 5;
    }
    //subtract a penny as many times as possible 
    while (cents>=1)
    {
        coin_counter = coin_counter + 1;
        cents = cents - 1;
    }
        
        printf("%d\n", coin_counter);
    
    
    
    
    
    
    
    
    
    
    
   
    
        
        
    
    
}

